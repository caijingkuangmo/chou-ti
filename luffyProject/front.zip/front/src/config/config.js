var config = {
    prefix: "/django-api",
}

export default config;