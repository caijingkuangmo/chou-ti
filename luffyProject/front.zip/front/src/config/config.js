var config = {
    prefix: "/django-api",
    apiPrefix: "/api/v1"
}

config.baseUrl = config.prefix + config.apiPrefix;

export default config;