<template>
    <div>
        <Nav></Nav>
        <h1>news</h1>
    </div>
</template>

<script>
import Nav from "@/components/index.vue"
export default {
    name:"news",
    components:{
        Nav
    },
    data () {
        return {
            
        }
    }
}
</script>

<style scoped>

</style>


