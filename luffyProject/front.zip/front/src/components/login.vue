<template>
    <div>
        login
    </div>
</template>

<script>
export default {
    name:"login",
    data () {
        return {
            
        }
    }
}
</script>

<style scoped>

</style>


