<template>
    <div>
        question
    </div>
</template>

<script>
export default {
    name:"course-item-question",
    data () {
        return {
            
        }
    }
}
</script>

<style scoped>

</style>


