<template>
    <div>
        comment
    </div>
</template>

<script>
export default {
    name:"course-item-chapter",
    data () {
        return {
            
        }
    }
}
</script>

<style scoped>

</style>


