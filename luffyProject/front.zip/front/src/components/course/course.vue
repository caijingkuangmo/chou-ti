<template>
    <div>
        <Nav></Nav>
        <h1>course</h1>
    </div>
</template>

<script>
import Nav from "@/components/index.vue"
export default {
    name:"course",
    components:{
        Nav
    },
    data () {
        return {
            
        }
    }
}
</script>

<style scoped>

</style>


